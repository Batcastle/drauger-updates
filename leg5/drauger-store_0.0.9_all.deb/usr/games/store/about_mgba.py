#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  about_mgba.py
#  
#  Copyright 2018 batcastle <draugeros@gmail.com>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, Pango
from ctypes import cdll, byref, create_string_buffer
from os import system
package="mpba-qt"

class welcome(Gtk.Window):
	
	def __init__(self):
		Gtk.Window.__init__(self, title="Drauger Store")
		self.grid=Gtk.Grid(orientation=Gtk.Orientation.VERTICAL,)
		self.add(self.grid)
		
		self.label = Gtk.Label()
		self.label.set_markup("<b>" + """
About
""" + "</b>")
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 2, 2, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Package: mgba-qt
Version: 0.5.2+dfsg1-3
Priority: optional
Section: universe/games
Source: mgba
Origin: Ubuntu
Bugs: https://bugs.launchpad.net/ubuntu/+filebug
Installed-Size: 2,004 kB
Homepage: http://mgba.io/
Download-Size: 1,026 kB


 mGBA is a new emulator for running Game Boy Advance games. 
 It aims to be faster
 and more accurate than many existing Game Boy Advance emulators, 
 as well as adding features that other emulators lack.
 .
 This package provides the Qt GUI frontend for mGBA.
 .
 Game Boy Advance is a registered trademark 
 of Nintendo of America Inc. mGBA is
 not affiliated with or endorsed by any 
 of the companies mentioned.
 """)
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 2, 3, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Install
""")
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 1, 4, 1, 1)
		
		self.button1 = Gtk.Button.new_from_icon_name("download",3)
		self.button1.connect("clicked", self.oninstallclicked)
		self.grid.attach(self.button1, 1, 5, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Back
""")
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 2, 4, 1, 1)
		
		self.button1 = Gtk.Button.new_from_icon_name("back",3)
		self.button1.connect("clicked", self.onbackclicked)
		self.grid.attach(self.button1, 2, 5, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Uninstall
""")
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 3, 4, 1, 1)
		
		self.button1 = Gtk.Button.new_from_icon_name("cancel",3)
		self.button1.connect("clicked", self.onuninstallclicked)
		self.grid.attach(self.button1, 3, 5, 1, 1)
		
		
	def oninstallclicked(self, button):
		system("bash /usr/games/store/install.sh %s" % (package))
		
	def onuninstallclicked(self, button):
		system("bash /usr/games/store/uninstall.sh %s" % (package))
		
	def onbackclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/nin.py")
		
	

def welcome_show():
	window = welcome()
	window.set_decorated(True)
	window.set_resizable(True)
	window.override_background_color(Gtk.StateType.NORMAL, Gdk.RGBA(1,1,1,1))
	window.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse("black"))
	window.set_opacity(0.0)
	window.set_position(Gtk.WindowPosition.CENTER)
	window.show_all()
	Gtk.main() 
	window.connect("delete-event", Gtk.main_quit)

welcome_show()

