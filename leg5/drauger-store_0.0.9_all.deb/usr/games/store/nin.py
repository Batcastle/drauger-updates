#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  nin.py
#  
#  Copyright 2018 batcastle <draugeros@gmail.com>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, Pango
from ctypes import cdll, byref, create_string_buffer
from os import system

class welcome(Gtk.Window):
	
	def __init__(self):
		Gtk.Window.__init__(self, title="Drauger Store")
		self.grid=Gtk.Grid(orientation=Gtk.Orientation.VERTICAL,)
		self.add(self.grid)
		
		self.label = Gtk.Label()
		self.label.set_markup("<b>" + """
Nintendo  
 """ + "</b>")
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 2, 2, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Desmume
""")
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 1, 3, 1, 1)
		
		self.button1 = Gtk.Button.new_from_icon_name("desmume",3)
		self.button1.connect("clicked", self.ondesmueclicked)
		self.grid.attach(self.button1, 1, 4, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Dolphin-emu   
 """)
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 4, 3, 1, 1)
		
		self.button2 = Gtk.Button.new_from_icon_name("dolphin-emu",3)
		self.button2.connect("clicked", self.ondolphinclicked)
		self.grid.attach(self.button2, 4, 4, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Mgba   
 """)
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 1, 6, 1, 1)
		
		self.button2 = Gtk.Button.new_from_icon_name("mgba",3)
		self.button2.connect("clicked", self.onmgbaclicked)
		self.grid.attach(self.button2, 1, 7, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Nestopia   
 """)
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 4, 6, 1, 1)
		
		self.button2 = Gtk.Button.new_from_icon_name("nestopia",3)
		self.button2.connect("clicked", self.onnestopiaclicked)
		self.grid.attach(self.button2, 4, 7, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Zsnes   
 """)
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 1, 9, 1, 1)
		
		self.button2 = Gtk.Button.new_from_icon_name("zsnes",3)
		self.button2.connect("clicked", self.onzsnesclicked)
		self.grid.attach(self.button2, 1, 10, 1, 1)
		
		self.label = Gtk.Label()
		self.label.set_markup("""
Back   
 """)
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 4, 9, 1, 1)
		
		self.button2 = Gtk.Button.new_from_icon_name("back",3)
		self.button2.connect("clicked", self.onbackclicked)
		self.grid.attach(self.button2, 4, 10, 1, 1)
		
    
	def ondesmueclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/about_desmume.py")
		
	def ondolphinclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/about_dolphin.py")
		
	def onmgbaclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/about_mgba.py")
		
	def onnestopiaclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/about_nestopia.py")
		
	def onzsnesclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/about_zsnes.py")
		
	def onbackclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/main_emu.py")		
	

def welcome_show():
	window = welcome()
	window.set_decorated(True)
	window.set_resizable(True)
	window.override_background_color(Gtk.StateType.NORMAL, Gdk.RGBA(1,1,1,1))
	window.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse("black"))
	window.set_opacity(0.0)
	window.set_position(Gtk.WindowPosition.CENTER)
	window.show_all()
	Gtk.main() 
	window.connect("delete-event", Gtk.main_quit)

welcome_show()

