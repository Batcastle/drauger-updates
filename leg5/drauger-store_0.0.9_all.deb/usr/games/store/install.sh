#!/bin/bash
# -*- coding: utf-8 -*-
#
#  install.sh
#  
#  Copyright 2018 Thomas Castleman <batcastle@External-HDD-8>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
zenity --notification --text="Installing $1 . . ."
pkexec apt-get -y install $1 && zenity --notification --text="'$1' installed successfully" || zenity --error --no-wrap --text="We're sorry. The package '$1' has refused to install. Please try to install this package again from either Synaptic Package Manager or some other Software Center."
