#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  main.py
#  
#  Copyright 2018 batcastle <draugeros@gmail.com>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, Pango
from ctypes import cdll, byref, create_string_buffer
from os import system
import subprocess



def grep(filename, arg):
    process = subprocess.Popen(['grep', '-sh', arg, filename], stdout=subprocess.PIPE)
    stdout, stderr = process.communicate()
    return stdout
  
    
class welcome(Gtk.Window):
	
	def __init__(self):
		Gtk.Window.__init__(self, title="Drauger Store")
		self.grid=Gtk.Grid(orientation=Gtk.Orientation.VERTICAL,)
		self.add(self.grid)
		
		self.label = Gtk.Label()
		self.label.set_markup("<b>" + """
EMULATORS   
 """ + "</b>")
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 2, 1, 1, 1)
		
		x_pos = 1
		y_neg1 = 3
		y_neg2 = 4
		comp = ["Atari", "Microsoft", "Nintendo", "Other", "Sony"]
		for x in comp:
			run=grep('/usr/games/store/emulators/apps/app.list', x)
			run=run.split()
			if run[1] == "none":
				continue
			else:
				self.label = Gtk.Label()
				self.label.set_markup("""
   %s   
 """ % (x))
				self.label.set_justify(Gtk.Justification.CENTER)
				self.grid.attach(self.label, x_pos, y_neg1, 1, 1)
				
				switch = {
					"Atari":"stella_stella",
					"Micrsoft":"microsoft",
					"Nintendo":"desmume",
					"Other":"add",
					"Sony":"pcsx2"
				}
				icon = switch.get(x, "chess")
				self.button1 = Gtk.Button.new_from_icon_name(icon,3)
				self.button1.connect("clicked", self.onbuttonclicked, x)
				self.grid.attach(self.button1, x_pos, y_neg2, 1, 1)
				
				if x_pos != 3:
					x_pos = x_pos+1
				else:
					x_pos = 1
					y_neg1 = y_neg1+2
					y_neg2 = y_neg2+2
					
		self.label = Gtk.Label()
		self.label.set_markup("""
Back 
 """)
		self.label.set_justify(Gtk.Justification.CENTER)
		self.grid.attach(self.label, 3, 5, 1, 1)
		
		self.button1 = Gtk.Button.new_from_icon_name("back",3)
		self.button1.connect("clicked", self.onbackclicked)
		self.grid.attach(self.button1, 3, 6, 1, 1)
				
				
	def onbuttonclicked(self, button, comp):
		Gtk.main_quit()
		if comp == "Atari":
			system("python /usr/games/store/emulators/menus/atari.py")
		elif comp == "Microsoft":
			system("python /usr/games/store/emulators/menus/ms.py")
		elif comp == "Nintendo":
			system("python /usr/games/store/emulators/menus/nin.py")
		elif comp == "Other":
			system("python /usr/games/store/emulators/menus/comp.py")
		elif comp == "Sony":
			system("python /usr/games/store/emulators/menus/sony.py")
		else:
			system("zenity --error --no-wrap --text='We are sorry. An error has occured.'")
	
	def onbackclicked(self, button):
		Gtk.main_quit()
		system("python /usr/games/store/core/main.py")		

		
		
def welcome_show():
	window = welcome()
	window.set_decorated(True)
	window.set_resizable(True)
	window.override_background_color(Gtk.StateType.NORMAL, Gdk.RGBA(1,1,1,1))
	window.modify_fg(Gtk.StateFlags.NORMAL, Gdk.color_parse("black"))
	window.set_opacity(0.0)
	window.set_position(Gtk.WindowPosition.CENTER)
	window.show_all()
	Gtk.main() 
	window.connect("delete-event", Gtk.main_quit)

welcome_show()
